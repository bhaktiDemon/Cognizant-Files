Project Name : Outreach

Overview : This is a Java Selenium project automates task on Be.cognizant page.It includes TestNG for testing , Page Object Model to make the project look simpler.

Rerquirements :

1.Validate current event displayed in Outreach.
2.Get event details from Outreach.
3.Validate all menus and sub-menus from Outreach.
4.Validate Filter option in Outreach
5.Validate event based on interest is visible in Outreach.
6.Validate event details in Outreach..

Dependencies :
•Selenium: <4.19.1>
•TestNG: <7.10.1>


Programming Language :
•Java

Framework:
•TestNG

Tool:
• Maven
• Selenium



