package Coursera;

import java.io.IOException;
import java.time.Duration;
import java.time.temporal.TemporalAmount;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class POM_SearchCourses {
	WebDriver driver;
	TakeScreenShot ss;
	//constructor
	public POM_SearchCourses(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	//locators of search box and search button
	@FindBy(xpath="//input[@placeholder='What do you want to learn?']") WebElement searchCourses; 
	@FindBy(xpath="//button[@class='nostyle search-button']//div") WebElement searchButton;
	
	//locators of english language 
	@FindBy(xpath="//span[text()='English']") WebElement englishBox;
	
	//locators of beginner checkbox
	@FindBy(id="cds-react-aria-45") WebElement beginnerBox;
	
	
	//locator of list of courses displayed
	@FindBy(xpath="//a/h3[@class='cds-CommonCard-title css-6ecy9b']") List<WebElement> coursesTitleList;
	
	//locator of list of courses duration
	@FindBy(xpath="//div[@class='cds-CommonCard-metadata']/p[@class=' css-vac8rf']") List<WebElement> coursesDurationList;
	
	//locator of list of courses rating
	@FindBy(xpath="//p[@class='css-2xargn']") List<WebElement> coursesRatingList;
	
	//locator of language button
	@FindBy(xpath = "//button[@data-track-component='expand_filter_items_button_language']") WebElement languageButton;
	
	//locator of languages list
	@FindBy(xpath = "//div[@data-testid='search-filter-group-Language']//span[@class='cds-checkboxAndRadio-labelContent css-tvqrra']/span") List<WebElement> languages;
	
	//locator of level
	@FindBy(xpath = "//div[@data-testid='search-filter-group-Level']//div[contains(@class,'css-nsxeb5')]") List<WebElement> levelList;
	
	//action method
	public void search() throws InterruptedException, IOException {
		ss = new TakeScreenShot(driver);
		
		searchCourses.sendKeys("Web Development Courses");
		Thread.sleep(3000);
		
		//search screen shot
		ss.takeScreenShotSearch();
		
		searchButton.click();
		Thread.sleep(3000);
		englishBox.click();
		Thread.sleep(3000);
		beginnerBox.click();
		Thread.sleep(3000);
		//screenshot
		ss.takeScreenShotFilter();
		
	}
	
	public void coursesList() {
		int index = 0;
		while(index<2) {
			System.out.println("Course Name: " + coursesTitleList.get(index).getText());
			String[] arr = coursesDurationList.get(index).getText().split(" · ");
			//System.out.println(Arrays.toString(arr));
			System.out.println("Duration: "+arr[arr.length-1]);
			System.out.println("Rating: " + coursesRatingList.get(index).getText()  +" star");
			System.out.println();
			arr = null;
			index++;
		}
	}
	
	public void languageDetails() {
		languageButton.click();
		System.out.println(languages.size());
		for(WebElement e : languages) {
			System.out.println(e.getText());
		}
		
	}
	
	public void level() {
		System.out.println(levelList.size());
		for(WebElement e : levelList) {
			System.out.println(e.getText());
		}
	}
	
}
