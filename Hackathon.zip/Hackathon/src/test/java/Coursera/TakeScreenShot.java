package Coursera;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class TakeScreenShot {
	WebDriver driver;
	//constructor
		public TakeScreenShot(WebDriver driver) { 
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	
	public void takeScreenShotSearch() throws IOException {
		String fileWithPath = "C:\\Users\\2332833\\eclipse-workspace\\Hackathon\\ScreenShot\\Search\\search.png";
		TakesScreenshot scrShot =((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		
		File DestFile=new File(fileWithPath);
		
		FileUtils.copyFile(SrcFile, DestFile);
	}
	
	public void takeScreenShotFilter() throws IOException {
		String fileWithPath = "C:\\Users\\2332833\\eclipse-workspace\\Hackathon\\ScreenShot\\FilterCourses\\filter.png";
		TakesScreenshot scrShot =((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		
		File DestFile=new File(fileWithPath);
		
		FileUtils.copyFile(SrcFile, DestFile);
	}
	
	public void takeScreenShotCampus() throws IOException {
		String fileWithPath = "C:\\Users\\2332833\\eclipse-workspace\\Hackathon\\ScreenShot\\Campus\\campus.png";
		TakesScreenshot scrShot =((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		
		File DestFile=new File(fileWithPath);
		
		FileUtils.copyFile(SrcFile, DestFile);
	}
	
	public void takeScreenShotForm() throws IOException {
		String fileWithPath = "C:\\Users\\2332833\\eclipse-workspace\\Hackathon\\ScreenShot\\Form\\form.png";
		TakesScreenshot scrShot =((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		
		File DestFile=new File(fileWithPath);
		
		FileUtils.copyFile(SrcFile, DestFile);
	}
	
	
}
