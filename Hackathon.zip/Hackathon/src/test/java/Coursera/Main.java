package Coursera;


import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import org.testng.annotations.Parameters;

public class Main {
	WebDriver driver;
	POM_SearchCourses sc;
	POM_Campus campus;
	static TakesScreenshot takesScreenshot;
	
	@BeforeClass
	@Parameters({"browser"})
	void setup(String browser) {
		
		if(browser.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}else if(browser.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.coursera.org/");
	}
	
  
	@DataProvider(name="data")
	String[][] inputValues(){
		
		String[][] data = {
				{"Bhakti","Kharate","12345",
				"9969054541","University/4 Year College",
				"SAKEC","Student","Student Affairs",
				"Courses for myself",
				"India","Maharashtra"}
				
		};
		return data;
	}
   
  @Test(priority=1)
  public void searchCourses() throws InterruptedException, IOException {
	  sc = new POM_SearchCourses(driver);
	  
	  sc.search();
	  takesScreenshot = (TakesScreenshot)driver;
	  
  }
  
  @Test(priority = 2)
  void coursesList() throws InterruptedException {
	  Thread.sleep(3000);
	  sc.coursesList();
  }
  
  @Test(priority = 3)
  void languageDetailsAndLevel() throws InterruptedException {
	  Thread.sleep(3000);
	  sc.languageDetails();
	  Thread.sleep(3000);
	  sc.level();
  }
  
  
  @Test(priority = 4)
  void getCampus() throws InterruptedException, IOException {
	  campus = new POM_Campus(driver);
	  
	  campus.getCampus();
	  
	  Thread.sleep(3000);  
  }
  
  
  @Test(priority = 5,dataProvider = "data")
	void formFill(String fname,String lname,String email,String phone,String instituteType,String collegeName,String title, String dept, String reason,String country,String state) throws IOException, InterruptedException {
		campus = new POM_Campus(driver);
	  	Thread.sleep(3000);
	  	campus.fillForm(fname, lname, email, phone, instituteType, collegeName, title, dept, reason, country, state);
		Thread.sleep(3000);
		
	}
	
	@AfterClass
	void tearDown() {
		driver.quit();
	}
	
	public static String captureScreen(String tname) throws IOException {
		// Current Date and Time
//		String timeStamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
		String targetFilePath = System.getProperty("user.dir") + "\\ReportScreenShots\\" + tname + ".png";
		File targetFile = new File(targetFilePath);
		sourceFile.renameTo(targetFile);
		return targetFilePath;
	}
}
