package Coursera;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class POM_Campus {
	WebDriver driver;
	TakeScreenShot ss;
	//constructor
	public POM_Campus(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//locators
	@FindBy(xpath = "//a[text()='For Enterprise']") WebElement enterprise;
	@FindBy(xpath = "//a[text()='For Campus']") WebElement campus;
	
	//locators for	Fill form
	@FindBy(id = "FirstName") WebElement firstName;
	@FindBy(id = "LastName") WebElement lastName;
	@FindBy(id = "Email") WebElement Email;
	@FindBy(id = "Phone") WebElement phoneNo;
	@FindBy(id = "Institution_Type__c") WebElement institute;
	@FindBy(id = "Company") WebElement Company;
	@FindBy(id = "Title") WebElement jobRole;
	@FindBy(id = "Department") WebElement department;
	@FindBy(id = "What_the_lead_asked_for_on_the_website__c") WebElement description;
	//@FindBy(id = "Self_reported_employees_to_buy_for__c") WebElement numberOfEmp;
	@FindBy(id = "Country") WebElement countryName;
	@FindBy(id = "State") WebElement StateName;
	@FindBy(xpath = "//button[text()='Submit']") WebElement submitButton;
	@FindBy(id = "ValidMsgEmail")WebElement errorMsg;
	
	//action methods
	public void getCampus() throws InterruptedException, IOException {
		ss = new TakeScreenShot(driver);
		
		enterprise.click();
		Thread.sleep(3000);
		campus.click();
		//ss
		ss.takeScreenShotCampus();
	}
	
	

	public void fillForm(String fname, String lname, String email, String phone, String instituteType,String collegeName, String title, String dept, String reason, String country, String state) throws IOException, InterruptedException {
		ss = new TakeScreenShot(driver);
		
		firstName.sendKeys(fname);
		lastName.sendKeys(lname);
		Email.sendKeys(email);
		phoneNo.sendKeys(phone);
		
		Select select = new Select(institute);
		select.selectByValue(instituteType);
		Company.sendKeys(collegeName);
		Select select2 = new Select(jobRole);
		select2.selectByValue(title);
		Select select3 = new Select(department);
		select3.selectByValue(dept);
		
		Select select4 = new Select(description);
		select4.selectByValue(reason);

	

		Select select6 = new Select(countryName);
		select6.selectByVisibleText(country);

		Select select7 = new Select(StateName);
		select7.selectByValue(state);
		
		
		
		submitButton.click();
		String msg = errorMsg.getText();
		Thread.sleep(3000);
		ss.takeScreenShotForm();
		System.out.println();
		System.out.println("Error: "+msg);
		
	}
}
