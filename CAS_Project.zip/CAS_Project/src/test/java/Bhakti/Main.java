package Bhakti;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import OutReach.PomBeCognizant;
import OutReach.PomOneCognizant;
import OutReach.PomOutReach;

public class Main {
	WebDriver driver;
	
	POM_BeCognizant beCogniObj;
	POM_OneCognizant outReachObj;
	POM_OutReach app;
	
	
	@BeforeClass
	void setup() {
		driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://be.cognizant.com");
		
		
	}
	
	
	@Test(priority = 1)
	void beCognizant() throws Exception {
		beCogniObj = new POM_BeCognizant(driver);
		Thread.sleep(10000);
		beCogniObj.getProfileDetails();
		app.takeScreenShot("beCognizant");
		
	}
	
	@Test(priority=2)
	void switchToOneCogni() throws IOException {
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get("https://onecognizant.cognizant.com/Home");
		app.takeScreenShot("oneCognizant");
		
	}
	
	@Test(priority = 3)
	void findOutReach() throws InterruptedException {
		outReachObj = new POM_OneCognizant(driver);
		outReachObj.clickSearchButton();

	}
	
	@Test(priority = 4)
	void outReach() throws IOException {
		driver.switchTo().frame("appFrame");
		app = new POM_OutReach(driver);
		app.menu();
		app.subMenu();
		
		//event listener card
		app.eventInterestCardList();
		
		app.takeScreenShot("outReach");
		
		
		
	}
	
	//Validate Search event filter option based on Location, Event type, Weekend/Weekdays, From date and To date and print the search results.
		@Test(priority = 5)
		void serachFilterButton() throws Exception {
			Thread.sleep(3000);
			
			app.clickSerachFilterButton();
			
		}
		
		//Selcting from date
		@Test(priority = 7)
		void fromDate() throws InterruptedException  {
			app.fromDateBButton();;
			
		}
		
		@Test(priority = 8)
		void toDate() throws IOException {
			app.getToDate();
			app.takeScreenShot("dates");
		}
		
		@Test(priority = 9)
		void filterSearchButton() throws IOException {
			//app.clickFilterSearchButton();
		}
		
		@Test(priority = 10)
		void displaySearchResults() throws Exception {
			
			app.displaySearchResult();
			Thread.sleep(3000);
			app.takeScreenShot("displaySearchResult");
			
		}
		
		@Test(priority = 11)
		void volunteerOption() throws Exception {
			app.myVolunteerOption();
			app.takeScreenShot("volunteerOption");
			
		}
		
		@AfterClass
		void closeBrowser() throws InterruptedException, IOException {
			
			Thread.sleep(5000);
			driver.quit();
		}
	
	
}
