package Bhakti;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class POM_BeCognizant {

	WebDriver driver;
	TakesScreenshot ss;
	
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public POM_BeCognizant(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

//	Beocognizant
	@FindBy(className = "_8ZYZKvxC8bvw1xgQGSkvvA==")
	WebElement profileButton;
	@FindBy(xpath = "//div[@id='mectrl_currentAccount_primary']")
	WebElement txt_username;
	@FindBy(id = "mectrl_currentAccount_secondary")
	WebElement txt_email;
	
//	oneCognizant
	@FindBy(xpath = "//div[text()='OneCognizant']") WebElement oncognizant;

	public void getProfileDetails() throws InterruptedException {
		
		wait.until(ExpectedConditions.visibilityOf(profileButton));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", profileButton);
		
		System.out.println("User Information:");
		Thread.sleep(6000);
		System.out.println(txt_username.getText());
		System.out.println(txt_email.getText());
	}
}
