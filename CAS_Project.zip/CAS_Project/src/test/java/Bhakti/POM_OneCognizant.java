package Bhakti;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class POM_OneCognizant {
	
	WebDriver driver;
	
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	
	//constructor
	POM_OneCognizant(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//locators 
	
	@FindBy(className = "searchTopBar") WebElement searchIcon;
	@FindBy(id = "oneCSearchTop") WebElement searchTextBox;
	@FindBy(xpath = "//div[@class='appsResultText' and text()='Outreach']") WebElement outReachButton;
	
	
	//action methods
	public void clickSearchButton() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOf(searchIcon));
		searchIcon.click();
		searchTextBox.sendKeys("Outreach");
		Thread.sleep(3000);
		outReachButton.click();
	}
	
}
