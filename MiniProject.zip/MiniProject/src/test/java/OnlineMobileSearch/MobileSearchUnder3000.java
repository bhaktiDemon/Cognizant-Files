package OnlineMobileSearch;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class MobileSearchUnder3000 {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		String search = "mobile smartphones under 30000";
		
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
		
		//Enter the search text in search box “mobile smartphones under 30000”
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(search);
		driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
		
		//validate the search string, number of pages( e.g. 1-16), number of items (over 90,000)
		WebElement str = driver.findElement(By.xpath("//span[contains(text(),'1-16')]"));
		String strString = str.getText();
		
		
		String[] strArray = strString.split(" "); 
		
		System.out.println("ONLINE MOBILE SEARCH");
		System.out.println();
		//validating page no
		String[] pageNo = strArray[0].split("-");
		int startPageNo = Integer.parseInt(pageNo[0]);
		int lastPageNo = Integer.parseInt(pageNo[1]);
		
		if(startPageNo>0 && lastPageNo>startPageNo) {
			System.out.println("Page no: "+strArray[0]);
		}
		
		//no of results 
		int intResults = Integer.parseInt(strArray[3].replace(",", ""));
		if(intResults>0) {
			System.out.println("Number of items: "+strArray[3]);
		}
		System.out.println();
		//validate the search string
		String actualText = driver.findElement(By.xpath("//span[@class='a-color-state a-text-bold']")).getText().replace("\"", "");
		if(actualText.equals(search)) {
			System.out.println("The search string is validated");
		}
		System.out.println();
		//clicking newest arrivals
		
	    driver.findElement(By.xpath("//span[@class='a-dropdown-prompt']")).click();
		
		driver.findElement(By.xpath("//a[@id='s-result-sort-select_4']")).click();
		
		
		//counting the features 
        List<WebElement> list = driver.findElements(By.xpath("//*[@id='a-popover-2']//li[@class='a-dropdown-item']"));
        System.out.println("Count of options: "+list.size());
        System.out.println();
        
        String newArr = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']/span[2]")).getText();
        if(newArr.equals("Newest Arrivals")) {
        	System.out.println("Newest Arrivals is enabled");
        }else {
        	System.out.println("Newest Arrivals is disabled");
        }
        
        //closing driver
        System.out.println();
        System.out.println("Closing the driver");
        driver.quit();																																																																																																																																																																																																													
		
		
	}

}
