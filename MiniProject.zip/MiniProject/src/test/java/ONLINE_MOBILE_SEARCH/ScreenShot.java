package ONLINE_MOBILE_SEARCH;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenShot {
	public static void takeScreenShot() throws IOException{
		String fileWithPath = "C:\\Users\\2332833\\eclipse-workspace\\MiniProject\\src\\test\\java\\Screenshots\\ss1.png";
		
		WebDriver driver = DriverSetUp.driver;
		TakesScreenshot scrShot =((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		
		File DestFile=new File(fileWithPath);
		
		FileUtils.copyFile(SrcFile, DestFile);
		
		
		
	}

}
