package ONLINE_MOBILE_SEARCH;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Main {

	//static WebDriver driver = DriverSetUp.driver;
	
	public static void main(String[] args) throws IOException {
		
				DriverSetUp.driverSetUp("chrome");
				
				WebDriver driver = DriverSetUp.driver;
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
				
				String search = "mobile smartphones under 30000";
				boolean stringValidate;
				
				//Enter the search text in search box “mobile smartphones under 30000”
				driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(search);
				driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
				
				//clicking newest arrivals
				
			    driver.findElement(By.xpath("//span[@class='a-dropdown-prompt']")).click();
				
				driver.findElement(By.xpath("//a[@id='s-result-sort-select_4']")).click();
				
				//validate the search string, number of pages( e.g. 1-16), number of items (over 90,000)
				WebElement str = driver.findElement(By.xpath("//span[contains(text(),'1-16')]"));
				String strString = str.getText();  //strString = 1-16 of over 1,000 results for
				
				
				String[] strArray = strString.split(" "); //["1-16","of","over","1,000","results","for"]
				
				System.out.println("ONLINE MOBILE SEARCH");
				System.out.println();
				//validating page no
				
				String[] pageNo = strArray[0].split("-");
				int startPageNo = Integer.parseInt(pageNo[0]); //1
				int lastPageNo = Integer.parseInt(pageNo[1]);  //16
				
				if(startPageNo>0 && lastPageNo>startPageNo) {
					System.out.println("Page no: "+strArray[0]);
				}
				
				//no of results 
				int intResults = Integer.parseInt(strArray[3].replace(",", "")); //1000
				if(intResults>0) {
					System.out.println("Number of items: "+strArray[3]);
				}
				System.out.println();
				
				//validate the search string
				//i.e : "mobile smartphones under 30000"
				String actualText = driver.findElement(By.xpath("//span[@class='a-color-state a-text-bold']")).getText().replace("\"", "");
				if(actualText.equals(search)) {
					System.out.println("The search string is validated");
					stringValidate = true;
				}else {
					stringValidate = false;
				}
				System.out.println();
				
				
				
				//counting the features i.e featured, Price: Low to High, Price: High to Low, Average, Newest Arrival
		        List<WebElement> list = driver.findElements(By.xpath("//*[@id='a-popover-2']//li[@class='a-dropdown-item']"));
		        System.out.println("Count of options: "+list.size());
		        System.out.println();
		        
		        String newArr = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']/span[2]")).getText();
		        if(newArr.equals("Newest Arrivals")) {
		        	System.out.println("Newest Arrivals is enabled");
		        }else {
		        	System.out.println("Newest Arrivals is disabled");
		        }
		        
		        System.out.println();
		        System.out.println("Taking Screenshot");
		        
		        // taking screenshot and entering data into excel
		        WritingDataIntoExcel.WritingData(strArray[0],strArray[3],stringValidate,list.size());
		        ScreenShot.takeScreenShot();
		        
		        //closing drivers
		        System.out.println("Closing Driver");
		        DriverSetUp.driverClose();
	}
	
	
	
	

}
