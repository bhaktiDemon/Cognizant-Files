package ONLINE_MOBILE_SEARCH;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverSetUp {
	public static WebDriver driver;
	
	
	public static void driverSetUp(String browser) {
		if(browser.equalsIgnoreCase("Chrome")) {
			driver= new ChromeDriver();
			
		}else if(browser.equalsIgnoreCase("Edge")) {
			driver = new EdgeDriver();
			
		}else {
			System.out.println("Incorrect Brower written");
		}
		
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		
		
		
	}
	
	public static void driverClose() {
		driver.quit();
	}
}
