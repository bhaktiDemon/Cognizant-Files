package ONLINE_MOBILE_SEARCH;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WritingDataIntoExcel {
	public static void WritingData(String pageNo,String noOfItems, boolean stringValidate, int count) throws IOException{
		System.out.println(System.getProperty("user.dir"));
		FileOutputStream file = new FileOutputStream(System.getProperty("user.dir")+"\\TestData\\WritingData.xlsx");
		// if the excel file is not present then fileoutputstream will create an empty excel file in the folder
		
		//creating workbook
		XSSFWorkbook workbook = new XSSFWorkbook();
		
		//creating sheet
		XSSFSheet sheet = workbook.createSheet();
		
		//creating first row
		XSSFRow row = sheet.createRow(0); 
		
		//creating cells for that row and adding data
		row.createCell(0).setCellValue("Page No");
		row.createCell(1).setCellValue(pageNo);
		
		
		//creating second row
		XSSFRow row2 = sheet.createRow(1);
		
		//creating cells for the row and adding data
		row2.createCell(0).setCellValue("No of Items");
		row2.createCell(1).setCellValue(noOfItems);
		
		//creating third row
		XSSFRow row3 = sheet.createRow(2);
				
		//creating cells for the row and adding data
		row3.createCell(0).setCellValue("Is the string validated?");
		row3.createCell(1).setCellValue(stringValidate);
		
		//creating fourth row
		XSSFRow row4 = sheet.createRow(3);
						
		//creating cells for the row and adding data
		row4.createCell(0).setCellValue("Count of options");
		row4.createCell(1).setCellValue(count);
		
		
		//attaching workbook back to the file
		workbook.write(file);
		
		workbook.close();
		file.close();
	}

}
